/*
 * "Copyright (c) 2005 Stanford University. All rights reserved.
 *
 * Permission to use, copy, modify, and distribute this software and
 * its documentation for any purpose, without fee, and without written
 * agreement is hereby granted, provided that the above copyright
 * notice, the following two paragraphs and the author appear in all
 * copies of this software.
 * 
 * IN NO EVENT SHALL STANFORD UNIVERSITY BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 * ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN
 * IF STANFORD UNIVERSITY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH
 * DAMAGE.
 * 
 * STANFORD UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE
 * PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND STANFORD UNIVERSITY
 * HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 * ENHANCEMENTS, OR MODIFICATIONS."
 */
/**
 * The C functions that allow TOSSIM-side code to access the SimMoteP
 * component.
 *
 * @author Philip Levis
 * @date   Nov 22 2005
 */
// $Id$

/**
* Further edited by for multi-channel TOSSIM, each channel uses different noise traces
*
* @author Bo Li of wustl
* @data Mar 19, 2012
*/

#ifndef SIM_MOTE_H_INCLUDED
#define SIM_MOTE_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

long long int sim_mote_euid(int mote);
void sim_mote_set_euid(int mote, long long int euid);
long long int sim_mote_start_time(int mote);
void sim_mote_set_start_time(int mote, long long int t);

bool sim_mote_is_on(int mote);
void sim_mote_turn_on(int mote);
void sim_mote_turn_off(int mote);

int sim_mote_get_variable_info(int mote, char* name, void** addr, size_t* len);
void sim_mote_enqueue_boot_event(int mote);

bool sim_mote_set_radio_channel(int mote, uint8_t newRadioChannel);   // MIKE_LIANG, Bo
uint8_t sim_mote_get_radio_channel(int mote);   // MIKE_LIANG, Bo																			


//Added by Bo, we have two real metods in SimMoteP, and the following encapsulations are 
//for use in sim_tossim.c
int* sim_mote_getTcpMsg(int mote); 
void sim_mote_setTcpMsg(int mote, int flow_id, int slot_id, int source_id, int node_id, int channel_id);

//added by Bo for forcing a sensor to do nothing if idle.
bool sim_mote_is_idle(int mote);
void sim_mote_enable_idle(int mote);
void sim_mote_disable_idle(int mote);

#ifdef __cplusplus
}
#endif
#endif // SIM_MOTE_H_INCLUDED